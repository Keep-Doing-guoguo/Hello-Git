package com.awen.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Check
 */
@WebServlet("/Check")
public class Check extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		String Code =request.getParameter("inCode");
		PrintWriter out = response.getWriter();
		
		out.print(Code);
		out.print((String)request.getSession().getAttribute("Code"));
		String user=request.getParameter("user");
		String password=request.getParameter("pass");
		String password1=request.getParameter("pass1");
		if(Code.equals((String)request.getSession().getAttribute("Code"))&&user.equals("123456")&&password.equals("123456")&&password1.equals("123456")){
			out.print("��ȷ");
		}else{
			out.print("����");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
